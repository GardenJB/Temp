import java.util.Scanner;

public class Algo1_서울_8_김두희 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// testCase 입력받기
		int testCase = sc.nextInt();
		
		// 정답 저장용 StringBuilder 선언
		StringBuilder sb = new StringBuilder();
		for(int tc=1; tc<=testCase; tc++) {
			
			// 최대 100억 달러까지 주어지므로 long 형태로 선언
			long N = sc.nextLong();
			
			// 갈색 은전과 은색 은전
			long brown = 7;
			long silver = 9;
			
			// 은전의 개수는 모두 silver로 지불했을 때가 최소 개수이므로 나누어떨어지면 N/silver가 정답.
			if(N % silver == 0) {
				sb.append(String.format("#%d %d\n", tc, N/silver));
				continue;
			}
			
			// 은색 은전의 개수의 초기값
			long silverCnt = N / silver;
						
			// 은전으로 지불하고 남은 금액
			long tmp = N % silver;
			
			// 최소공배수는 63이므로 9달러 은전이 7개 이상 빠지면 같은 경우의 수가 반복되므로 종료
			// silverCnt가 0보다 작아지면 불가능하므로 종료
			// silver로 지불하고 남은 값이 brown으로 나눠지면 종료
			int cnt = 0;
			while(cnt < 8 && silverCnt > 0 && tmp % brown != 0) {
				// silver로 지불하고 남은 금액을 brown으로 지불할 수 없다면,
				// silver로 지불했던 동전의 개수를 하나 줄이고 남은 금액을 silver(9)만큼 올려준다.
				silverCnt--;
				tmp += silver;
				cnt++;
			}
						
			// silver로 지불하고 남은 값이 brown으로 나눠지면 
			// silver로 지불한 동전 개수와 brown으로 지불한 동전 개수의 합이 최솟값이다.
			if(tmp % brown == 0) {
				sb.append(String.format("#%d %d\n", tc, silverCnt + tmp/brown));
			} 
			// 아닌 경우 지불할 수 없는 경우이므로 종료
			else {
				sb.append(String.format("#%d %d\n", tc, -1));
			}
		}
		// 결과를 출력한다.
		System.out.println(sb.toString());
		sc.close();
	}
}
