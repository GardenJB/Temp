import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Algo2_서울_8_김두희 {
	
	// 정점의 번호와 난이도를 묶어줄 내부클래스 생성
	private static class Pair {
		int to, point;
		
		private Pair(int to, int point) {
			this.to = to;
			this.point = point;
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// testCase 입력받기
		int testCase = sc.nextInt();
		
		// 정답 저장용 StringBuilder
		StringBuilder sb = new StringBuilder();
		
		// testCase만큼 반복 진행
		for(int tc=1; tc<=testCase; tc++) {
			
			// 과목의 수 N과 선수관계 정보의 개수 M
			int N = sc.nextInt();
			int M = sc.nextInt();
			
			// 간선을 저장할 인접리스트 선언
			ArrayList<Pair>[] edges = new ArrayList[N+1];
			
			// 인접리스트 초기화
			for(int i=0; i<=N; i++) edges[i] = new ArrayList<>();
			
			// 난이도를 저장할 배열과 진입차수 개수를 저장할 indegree 배열 선언
			int[] point = new int[N+1];
			int[] indegree = new int[N+1];
			
			// 난이도 입력받기
			for(int i=1; i<=N; i++) {
				point[i] = sc.nextInt();
			}
			
			// 간선 입력받기
			for(int i=0; i<M; i++) {
				// 시작 정점와 도착정점 번호 입력받기 
				int from = sc.nextInt();
				int to = sc.nextInt();
				
				// from idx에 to를 추가하는데, 난이도도 함께 넣는다.
				edges[from].add(new Pair(to, point[to]));
				
				// to는 진입차수가 증가하는 것이므로  indegree 상승
				indegree[to]++;
			}
			
			// 난이도가 낮은 순으로 수강해야하므로 PriorityQueue를 이용한다. (point 순으로 정렬)
			PriorityQueue<Pair> queue = new PriorityQueue<>((o1, o2) -> o1.point - o2.point);
			
			// indegree가 0인 경우 선수과목이 없는 것이므로 queue에 넣는다.
			for(int i=1; i<=N; i++) {
				if(indegree[i] == 0) {
					queue.offer(new Pair(i, point[i]));
				}
			}
			// testCase 번호 입력
			sb.append("#" + tc + " ");
			
			// queue가 빌 때까지 반복
			while(!queue.isEmpty()) {
				// queue에서 꺼내고 StringBuilder에 저장
				Pair p = queue.poll();
				sb.append(p.to + " ");
				
				// 해당 정점와 연결된 정점의 indegree값을 1씩 줄여준다.
				for(Pair next : edges[p.to]) {
					indegree[next.to]--;
					
					// 만약 해당 정점의 진입차수가 0이 되었다면 선수과목이 모두 완료된 것이므로 queue에 넣어준다.
					if(indegree[next.to] == 0) {
						queue.offer(next);
					}
				}
			}
			// 개행문자 입력
			sb.append("\n");
		}
		// 정답 출력
		System.out.println(sb);
		sc.close();
	}
}
