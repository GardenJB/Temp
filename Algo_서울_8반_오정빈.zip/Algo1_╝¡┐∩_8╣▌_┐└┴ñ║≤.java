import java.util.Scanner;
import java.util.StringTokenizer;

public class Algo1_서울_8반_오정빈 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringTokenizer st = new StringTokenizer(sc.nextLine());
		
		//test case 반복
		int t = Integer.parseInt(st.nextToken());
		for(int tc=1; tc<=t; tc++) {
			
			st = new StringTokenizer(sc.nextLine());
			//물건 가격 n
			long n = Long.parseLong(st.nextToken());
			
			//동전의 개수
			long cnt=0;
			
			//우선 가치가 큰 은색 은전을 낼 수 있는만큼 더해주기
			cnt+=n/9;
			//물건 가치 조정
			n=n%9;
			
			while(n>=0) {
				//남는 가격이 없다면 종료
				if(n==0)
					break;
				//나머지가 작은 가치 갈색 은전으로 낼 수 있는 경우
				else if(n%7==0) {
					cnt+=n/7;
					break;
				}
				//갈색 은전으로 나누어 낼 수 없는 경우 은색 은전의 개수를 줄여가면서 갈색 은전으로 나누어지는 경우 찾기
				else {
					cnt--;
					n+=9;
					if(n%7==0) {
						cnt+=n/7;
						break;
					}
					//두 동전으로 지불 불가능한 경우
					if(cnt==0) {
						cnt=-1;
						break;
					}
					
				}
			}
			System.out.println("#"+tc+" "+cnt);
			
		}
	}

}
