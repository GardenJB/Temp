import java.util.Arrays;
//import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Algo2_서울_8반_오정빈 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringTokenizer st = new StringTokenizer(sc.nextLine());
		
		//test case 반복 
		int t = Integer.parseInt(st.nextToken());
		for(int tc=1; tc<=t; tc++) {
			
			//과목 수 n, 정보 수 m
			st = new StringTokenizer(sc.nextLine());
			int n = Integer.parseInt(st.nextToken());
			int m = Integer.parseInt(st.nextToken());
			
			//과목 배열  번호, 우선과목 수, 난이도, 체크
			int[][] arr = new int[n+1][4];
			arr[0][3]=1;
			//우선 순위 
			int[][] arr2 = new int[m][2];
			
			//과목 번호, 난이도 저장
			st = new StringTokenizer(sc.nextLine());
			for(int i=1; i<=n; i++) {
				arr[i][0]=i;
				arr[i][2]= Integer.parseInt(st.nextToken());
			}
			
			for(int i=0; i<m; i++) {
				st = new StringTokenizer(sc.nextLine());
				//우선순위 과목 a
				arr2[i][0]= Integer.parseInt(st.nextToken());
				//대상 과목 b
				arr2[i][1]= Integer.parseInt(st.nextToken());
				//대상 과목 b의 필요 우선과목수 더하기
				arr[arr2[i][1]][1]++;
			}
			
			//정렬
			Arrays.sort(arr, (o1, o2) -> {
				//우선순위 과목 수 오름차
				if(o1[1]!= o2[1]) 
					return o1[1]-o2[1];
				//우선순위 같은경우 난이도 오름차
				else
					return o1[2]-o2[2];
				
			});
			
//			for(int[] ar : arr) {
//				System.out.println(ar[0]);
//			}
			
			//수강 상태
			int[] temp = new int[n];
			int k=0;
			
			
//			PriorityQueue<int[]> pq = new PriorityQueue<>((o1, o2) -> {
//				//우선순위 과목 수 오름차
//				if(o1[1]!= o2[1]) 
//					return o1[1]-o2[1];
//				//우선순위 같은경우 난이도 오름차
//				else
//					return o1[2]-o2[2];
//				
//			});
//			
//			//과목들 저장
//			for(int i=1; i<=n; i++) {
//				pq.add(arr[i]);
//			}
//			
//			while(!pq.isEmpty()) {
//				int[] ar1 = pq.peek();
//			    //선수과목
//				int a = ar1[0];
//				for(int i=0; i<m; i++) {
//					if(arr2[i][0]==a) {
//						//후순위 과목
//						int b = arr2[i][1];
//						//큐에서 찾기
//					}
//				}
//				
//			}
			
			
			outer :
			while(true) {
				for(int i=1; i<=n; i++) {
					//수강 안 한 과목에서
					if(arr[i][3]==0) {
						arr[i][3]=1;
						//선수과목 번호
						int a = arr[i][0];
						//후순위 관목이 존재한다면
						for(int j=0; j<m; j++) {
							if(arr2[j][0]==a) {
								//후순위 과목 번호
								int b = arr2[j][1];
								for(int[] ar : arr) {
									//선수 과목 수 줄여주기
									if(ar[0]==b)
										ar[1]--;
								}
							}
						}
						
						//수강한 과목에 넣기
						temp[k]=a;
						k++;
						if(k==n) break outer;
						
						//정렬
						Arrays.sort(arr, (o1, o2) -> {
							//우선순위 과목 수 오름차
							if(o1[1]!= o2[1]) 
								return o1[1]-o2[1];
							//우선순위 같은경우 난이도 오름차
							else
								return o1[2]-o2[2];
							
						});
						
						continue outer;
					}
				}
			}
			
			String ans = "#"+tc+" ";
			for(int tt : temp) {
				ans+=tt+" ";
			}
			System.out.println(ans);
		}
	}
}
